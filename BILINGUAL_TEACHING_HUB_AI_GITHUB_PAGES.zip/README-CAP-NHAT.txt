BILINGUAL TEACHING HUB AI — VISUAL SGK EDITION

Tích hợp 110 hướng dẫn khai thác hình song ngữ trực tiếp vào website hiện tại.
Nguồn 5 SGK lớp 10 + 4 khung chương trình người dùng cung cấp.
Giữ nguyên nội dung, mô phỏng, bài tập đã có; thêm tab hướng dẫn hình trong Học qua hình & công thức.
Mỗi bài có: tham chiếu trang bắt đầu bài theo mục lục; mô tả Việt/Anh; câu hỏi; gợi ý; 4 từ khóa; phóng to, tải hình SVG tự dựng, in.
Vì bản quyền SGK, website công khai sử dụng sơ đồ tự vẽ dựa vào nội dung, không nhúng trang SGK gốc.
Các mục và sơ đồ chưa được giáo viên từng môn phê duyệt. Số trang là vị trí bắt đầu bài theo mục lục, không phải số hình/ảnh cụ thể.

Cài đặt GitHub: tải ZIP chứa index.html và các thư mục assets, data; tên nén đúng BILINGUAL_TEACHING_HUB_AI_GITHUB_PAGES.zip như workflow cũ.
