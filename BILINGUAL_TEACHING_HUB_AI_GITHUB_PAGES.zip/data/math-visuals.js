/* Original SVG teaching diagrams for 27 Mathematics 10 textbook lessons.
   They are NOT scanned/reproduced textbook illustrations and require subject-teacher review. */
(() => {
'use strict';
const ITEMS = [
['logic','Mệnh đề và phép kéo theo','Truth values and implication','Nếu P đúng và Q sai, P ⇒ Q đúng hay sai?','False: an implication with a true premise and false conclusion is false.'],
['venn','Tập hợp và phép toán','Set operations','Miền giao A ∩ B nằm ở đâu?','The overlap of sets A and B.'],
['halfplane','Miền nghiệm của bất phương trình','Solution half-plane','Điểm (0;2) có thỏa y ≥ 0.5x + 1 không?','Yes: 2 ≥ 1.'],
['system','Giao của hai nửa mặt phẳng','Intersection of half-planes','Miền nghiệm hệ là phần nào?','The common shaded region.'],
['trig','Góc tù trên đường tròn lượng giác','Unit semicircle','cos 120° dương hay âm?','Negative.'],
['triangle','Cạnh, góc và định lý cosin','Triangle and cosine rule','Góc A nằm giữa hai cạnh nào?','Sides b and c.'],
['vector','Vectơ có hướng','Directed segment','Đổi chiều mũi tên có làm thay đổi vectơ?','Yes, its direction changes.'],
['add','Tổng hai vectơ','Parallelogram rule','Vectơ tổng a+b là đường nào?','The diagonal from the common tail.'],
['scalar','Tích của số với vectơ','Scalar multiplication','−a cùng chiều hay ngược chiều với a?','Opposite direction.'],
['coords','Vectơ tọa độ','Vector components','Từ A(1;1) đến B(4;3) có tọa độ nào?','(3,2).'],
['dot','Tích vô hướng','Dot product','Góc 90° thì tích vô hướng bằng bao nhiêu?','Zero.'],
['error','Số gần đúng và sai số','Approximate value ± error','Giá trị 5.1 có nằm trong khoảng 5 ± 0.2?','Yes.'],
['centre','Trung bình và trung vị','Mean and median','Giá trị 8 ảnh hưởng mạnh hơn tới đại lượng nào?','The mean.'],
['spread','Biểu đồ hộp và râu','Box-and-whisker plot','IQR là hiệu hai giá trị nào?','Q3 − Q1.'],
['function','Ánh xạ hàm số','Function mapping','Một x có thể ứng với hai f(x) khác nhau không?','No.'],
['quadratic','Parabol và trục đối xứng','Quadratic function','Đỉnh của y=(x−1)²−2 là đâu?','(1,−2).'],
['sign','Dấu của tam thức bậc hai','Quadratic sign chart','Với (x−1)(x−3), khoảng (1,3) có dấu gì?','Negative.'],
['substitution','Đặt ẩn phụ t=x²','Quadratic substitution','Tại sao phải giữ điều kiện t≥0?','Because t=x² is non-negative.'],
['line','Phương trình đường thẳng','Equation of a line','Đường thẳng hệ số góc âm tăng hay giảm?','It decreases left-to-right.'],
['lines','Vị trí tương đối hai đường thẳng','Relative position of lines','Hai đường cùng hệ số góc và khác tung độ gốc?','They are parallel.'],
['circle','Phương trình đường tròn','Circle equation','Tâm I(2;−1), r=3: bán kính bằng mấy?','3.'],
['conics','Ba đường conic','Ellipse, parabola, hyperbola','Hypebol có mấy nhánh?','Two.'],
['tree','Quy tắc đếm theo sơ đồ cây','Counting tree','3 áo và 2 quần tạo bao nhiêu bộ?','6.'],
['permute','Hoán vị của ba phần tử','Permutations','ABC và BAC là cùng cách sắp xếp?','No.'],
['pascal','Tam giác Pascal','Pascal triangle','Hệ số a²b² của (a+b)⁴?','6.'],
['probability','Không gian mẫu của xúc xắc','Sample space','Xác suất ra số chẵn của xúc xắc đều?','3/6=1/2.'],
['practice','Không gian mẫu hai đồng xu','Two coin tosses','Xác suất đúng một lần ngửa?','2/4=1/2.']
];
const BLUE='#2b6596',TEAL='#11918b',GOLD='#dda757',CORAL='#d36b59',INK='#234761',FAINT='#dfeaf2';
const T=(x,y,t,fill=INK,size=15,weight=600,anchor='middle')=>`<text x="${x}" y="${y}" fill="${fill}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}" font-family="Arial, sans-serif">${t}</text>`;
const R=(x,y,w,h,fill='#eff7fb',stroke='#ccdfe9',rad=12)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rad}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
const L=(x1,y1,x2,y2,color=BLUE,width=3,dash='')=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}" stroke-linecap="round" ${dash?`stroke-dasharray="${dash}"`:''}/>`;
const C=(x,y,r,fill='#eef8f6',stroke=TEAL,w=2)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="${stroke}" stroke-width="${w}"/>`;
const P=(pts,fill,stroke='none',opacity=1)=>`<polygon points="${pts}" fill="${fill}" stroke="${stroke}" opacity="${opacity}"/>`;
const dot=(x,y,c=TEAL)=>C(x,y,5,c,c,0);
const arrow=(x1,y1,x2,y2,col=TEAL,w=4)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${col}" stroke-width="${w}" stroke-linecap="round" marker-end="url(#head-${col===CORAL?'coral':col===GOLD?'gold':'teal'})"/>`;
const labels=(items)=>items.map(a=>T(...a)).join('');
const axes=(ox=400,oy=196,step=43)=>{let s='';for(let x=ox%step;x<800;x+=step)s+=L(x,14,x,342,'#e6eef4',1);for(let y=oy%step;y<360;y+=step)s+=L(12,y,788,y,'#e6eef4',1);return s+arrow(26,oy,760,oy,INK,2)+arrow(ox,336,ox,24,INK,2)+T(764,oy-11,'x')+T(ox+13,26,'y')};
const plot=(fn,xMin=-7,xMax=7,ox=400,oy=195,sx=43,sy=43,col=BLUE)=>{let s='',active=false;for(let x=xMin;x<=xMax+.01;x+=.055){const y=fn(x),px=ox+sx*x,py=oy-sy*y;if(!Number.isFinite(y)||py<-30||py>385){active=false;continue} s+=(active?'L':'M')+px.toFixed(1)+','+py.toFixed(1)+' ';active=true}return `<path d="${s}" fill="none" stroke="${col}" stroke-width="4.3" stroke-linecap="round" stroke-linejoin="round"/>`};
const makeScene=k=>{
 let s='';switch(k){
 case 'logic':s=R(60,65,260,180,'#edf7fb')+R(480,65,260,180,'#e8f8f4')+T(190,112,'P: 2 &gt; 1',INK,23)+T(190,153,'TRUE',TEAL,27)+T(610,112,'Q: 2 &lt; 1',INK,23)+T(610,153,'FALSE',CORAL,27)+arrow(325,155,476,155)+T(402,139,'P implies Q',BLUE,19)+T(405,296,'True -> False is FALSE',CORAL,20);break;
 case 'venn':s=C(345,167,116,'#ebf6fd','#679dc4',3)+C(460,167,116,'#fff5e7',GOLD,3)+`<path d="M402.5 66.2 A116 116 0 0 1 402.5 267.8 A116 116 0 0 1 402.5 66.2" fill="#32a899" fill-opacity=".47"/>`+T(289,172,'A',BLUE,24)+T(515,172,'B',CORAL,24)+T(402,178,'A ∩ B',INK,22)+T(402,328,'Union A and B',BLUE,19);break;
 case 'halfplane':s=axes()+P('100,40 720,40 720,50 100,316','#67c5bd','none',.21)+L(146,304,650,52,TEAL,4)+T(560,85,'y ≥ 0.5x + 1',TEAL,20)+dot(400,110,CORAL)+T(462,110,'(0,2)  ✓',CORAL,18)+T(530,315,'Boundary included',INK,15);break;
 case 'system':s=axes()+P('165,50 660,50 530,180 310,270','#7ac8c3','none',.34)+P('300,60 660,60 490,235 175,305','#ffc968','none',.30)+L(190,298,615,70,TEAL,4)+L(220,64,622,285,CORAL,4)+T(225,62,'Feasible region',TEAL,19)+T(583,312,'Intersection',CORAL,18);break;
 case 'trig':s=L(125,260,675,260,INK,2)+L(400,320,400,38,INK,2)+`<path d="M220 260 A180 180 0 0 1 580 260" fill="none" stroke="${BLUE}" stroke-width="5"/>`+arrow(400,260,310,104,TEAL)+L(310,104,310,260,CORAL,2,'5 5')+dot(310,104)+T(270,94,'θ=120°',INK,21)+T(310,282,'cos θ &lt; 0',CORAL,17)+T(440,135,'sin θ &gt; 0',TEAL,17);break;
 case 'triangle':s=P('200,272 620,272 395,75','#ecf6fc',BLUE)+labels([[175,280,'B',INK,23],[644,280,'C',INK,23],[395,59,'A',INK,23],[298,169,'c',TEAL,23],[510,171,'b',GOLD,23],[412,298,'a',BLUE,23]])+`<path d="M358 272 A36 36 0 0 1 373 240" stroke="${CORAL}" stroke-width="3" fill="none"/>`+T(401,235,'A',CORAL,18)+T(401,345,'a² = b² + c² − 2bc cos A',INK,18);break;
 case 'vector':s=C(180,248,9,'#fff',BLUE)+arrow(188,240,612,101,TEAL,6)+dot(620,98,CORAL)+T(167,283,'A: initial point',INK,18)+T(622,78,'B: endpoint',INK,18)+T(400,150,'AB vector',TEAL,23);break;
 case 'add':s=arrow(202,265,472,265,TEAL,5)+arrow(202,265,330,93,BLUE,5)+L(330,93,600,93,BLUE,2,'7 6')+L(472,265,600,93,TEAL,2,'7 6')+arrow(202,265,598,94,CORAL,5)+labels([[321,293,'a',TEAL,21],[244,156,'b',BLUE,21],[480,182,'a + b',CORAL,23]]);break;
 case 'scalar':s=arrow(115,97,335,97,TEAL,5)+arrow(115,180,580,180,BLUE,5)+arrow(580,262,115,262,CORAL,5)+labels([[365,102,'a',TEAL,20],[614,185,'2a',BLUE,20],[366,269,'−2a',CORAL,20]]);break;
 case 'coords':s=axes(315,267,47)+arrow(362,220,503,126,TEAL,5)+L(503,126,503,220,CORAL,2,'7 5')+L(362,220,503,220,BLUE,2,'7 5')+T(341,238,'A(1,1)',INK,17)+T(529,114,'B(4,3)',INK,17)+T(437,248,'Δx = 3',BLUE,17)+T(557,180,'Δy = 2',CORAL,17);break;
 case 'dot':s=arrow(190,270,620,270,TEAL,5)+arrow(190,270,395,70,BLUE,5)+`<path d="M253 270 A63 63 0 0 0 236 222" fill="none" stroke="${GOLD}" stroke-width="4"/>`+T(282,242,'θ',GOLD,23)+T(630,284,'a',TEAL,23)+T(401,65,'b',BLUE,23)+T(430,341,'a · b = |a||b| cos θ',INK,19);break;
 case 'error':s=L(105,203,690,203,INK,4)+[3,4,5,6,7].map((v,i)=>L(145+i*125,193,145+i*125,214,INK,2)+T(145+i*125,239,String(v),INK,16)).join('')+R(370,159,63,83,'#cdf0e9','none',0)+L(376,175,428,175,TEAL,3)+dot(400,203,CORAL)+T(400,142,'5 ± 0.2',TEAL,22)+T(400,295,'[4.8, 5.2]',INK,19);break;
 case 'centre':{const values=[2,3,3,4,8];s=L(110,272,690,272,INK,2)+[1,2,3,4,5,6,7,8].map((n,i)=>L(115+74*i,263,115+74*i,281,INK,1)+T(115+74*i,300,String(n),INK,14)).join('');let counts={};values.forEach(v=>{const old=counts[v]||0;counts[v]=old+1;s+=dot(115+(v-1)*74,246-old*28,TEAL)});s+=T(410,77,'Mean = 4',CORAL,22)+T(410,112,'Median = 3',BLUE,22);break;}
 case 'spread':s=L(104,223,702,223,INK,3)+L(145,196,145,250,BLUE,3)+L(650,196,650,250,BLUE,3)+L(145,223,235,223,BLUE,4)+L(575,223,650,223,BLUE,4)+R(235,166,340,114,'#e4f6f1','#46a9a1',1)+L(418,166,418,280,CORAL,4)+labels([[145,274,'Min',INK,17],[235,303,'Q1',INK,17],[418,303,'Median',CORAL,17],[575,303,'Q3',INK,17],[650,274,'Max',INK,17],[400,93,'IQR = Q3 − Q1',BLUE,22]]);break;
 case 'function':s=R(90,48,200,255,'#eaf5ff',BLUE,25)+R(500,48,200,255,'#eafaf2',TEAL,25)+labels([[190,83,'INPUT x',BLUE,20],[600,83,'OUTPUT f(x)',TEAL,20],[186,138,'1',INK,20],[186,213,'2',INK,20],[600,138,'3',INK,20],[600,213,'5',INK,20]])+arrow(222,136,558,136)+arrow(222,207,558,207)+T(400,317,'f(x) = 2x + 1',INK,21);break;
 case 'quadratic':s=axes()+plot(x=>(x-1)*(x-1)-2,-4,6,400,190,55,40,TEAL)+L(455,55,455,320,CORAL,2,'8 6')+dot(455,270,CORAL)+T(540,284,'Vertex (1, −2)',CORAL,18)+T(562,70,'y=(x−1)²−2',INK,21);break;
 case 'sign':s=axes()+plot(x=>(x-1)*(x-3),-2,5,370,190,75,35,BLUE)+T(445,215,'x=1',CORAL,17)+T(596,215,'x=3',CORAL,17)+T(525,303,'negative on (1,3)',CORAL,17);break;
 case 'substitution':s=R(52,93,214,151,'#f0f7fd',BLUE)+R(302,93,198,151,'#effaf4',TEAL)+R(535,93,211,151,'#fff5e9',GOLD)+labels([[159,139,'x⁴−5x²+4=0',BLUE,21],[398,139,'t=x²',TEAL,23],[644,139,'t²−5t+4=0',INK,20],[159,200,'Original equation',INK,15],[398,200,'t ≥ 0',CORAL,19],[644,200,'Quadratic',INK,17]])+arrow(265,169,297,169)+arrow(500,169,531,169);break;
 case 'line':s=axes()+plot(x=>-.5*x+1,-7,7,400,196,43,43,TEAL)+dot(400,153,CORAL)+dot(486,196,CORAL)+T(534,112,'y = −0.5x + 1',TEAL,22);break;
 case 'lines':s=R(30,35,346,282,'#f3f8fc')+R(424,35,346,282,'#fbf9f2')+L(72,240,316,110,BLUE,5)+L(72,275,316,145,TEAL,5)+L(462,245,726,100,BLUE,5)+L(483,115,700,270,CORAL,5)+T(196,68,'PARALLEL',BLUE,18)+T(595,68,'INTERSECTING',CORAL,18);break;
 case 'circle':s=axes()+C(480,235,122,'#e9f6fe',BLUE,4)+dot(480,235,CORAL)+arrow(480,235,602,235,TEAL,3)+T(481,211,'I(2,−1)',CORAL,20)+T(540,225,'r=3',TEAL,19)+T(390,49,'(x−2)²+(y+1)²=9',INK,20);break;
 case 'conics':s=R(22,35,242,275,'#f7fbfe')+R(279,35,242,275,'#f7fbfe')+R(536,35,242,275,'#f7fbfe')+`<ellipse cx="143" cy="173" rx="100" ry="63" fill="none" stroke="${BLUE}" stroke-width="5"/>`+`<path d="M311 245 Q395 75 481 245" fill="none" stroke="${TEAL}" stroke-width="5"/>`+`<path d="M562 90 Q690 173 562 258 M755 90 Q626 173 755 258" fill="none" stroke="${CORAL}" stroke-width="5"/>`+labels([[143,300,'Ellipse',BLUE,20],[400,300,'Parabola',TEAL,20],[657,300,'Hyperbola',CORAL,20]]);break;
 case 'tree':s=C(110,180,12,TEAL,TEAL)+[70,180,290].map((y,i)=>{let a=arrow(122,180,360,y,BLUE,2)+T(358,y-17,'Top '+(i+1),BLUE,17);[y-28,y+28].forEach((z,j)=>{a+=arrow(374,y,628,z,TEAL,2)+T(678,z+5,'P'+(j+1),INK,16)});return a}).join('')+T(419,339,'3 × 2 = 6 combinations',INK,20);break;
 case 'permute':s=labels([[400,57,'3! = 3 × 2 × 1 = 6',TEAL,24]])+['ABC','ACB','BAC','BCA','CAB','CBA'].map((v,i)=>{const col=i%3,row=Math.floor(i/3);return R(93+col*214,91+row*110,172,83,'#edf7fb',BLUE)+T(179+col*214,142+row*110,v,INK,27)}).join('');break;
 case 'pascal':{let rows=[[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]];s=rows.map((a,i)=>a.map((x,j)=>{const px=400-35*i+70*j,py=68+56*i;return C(px,py,26,i===4?'#e7f8f1':'#edf5fa',i===4?TEAL:BLUE,2)+T(px,py+6,String(x),INK,17)}).join('')).join('')+T(400,348,'(a+b)⁴ = a⁴+4a³b+6a²b²+4ab³+b⁴',INK,19);break;}
 case 'probability':s=[1,2,3,4,5,6].map((n,i)=>{const x=136+(i%3)*258,y=70+Math.floor(i/3)*135;return R(x,y,167,108,n%2===0?'#dff6ec':'#f2f5fb',n%2===0?TEAL:BLUE)+T(x+84,y+71,String(n),n%2===0?TEAL:BLUE,43)}).join('')+T(411,347,'P(even) = 3/6 = 1/2',INK,18);break;
 case 'practice':s=['HH','HT','TH','TT'].map((v,i)=>{const x=105+(i%2)*326,y=52+Math.floor(i/2)*126;return R(x,y,265,101,v==='HT'||v==='TH'?'#e9f9f1':'#f3f7fc',v==='HT'||v==='TH'?TEAL:BLUE)+T(x+132,y+61,v,INK,31)}).join('')+T(408,333,'P(exactly one H) = 2/4',INK,19);break;
 }
 return `<svg viewBox="0 0 800 360" role="img" aria-label="${ITEMS.find(a=>a[0]===k)?.[1]||'Hình minh họa Toán học'}" xmlns="http://www.w3.org/2000/svg"><defs><marker id="head-teal" markerWidth="8" markerHeight="8" refX="6.5" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8 Z" fill="${TEAL}"/></marker><marker id="head-coral" markerWidth="8" markerHeight="8" refX="6.5" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8 Z" fill="${CORAL}"/></marker><marker id="head-gold" markerWidth="8" markerHeight="8" refX="6.5" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8 Z" fill="${GOLD}"/></marker></defs>${s}</svg>`;
};
const Escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function render(id){const match=/^math-10-(\d+)$/.exec(id||'');if(!match)return '';const n=Number(match[1]);if(n<1||n>27)return '';
const [kind,vi,en,question,answer]=ITEMS[n-1];return `<section class="math-vis-library" id="math-visual-lesson"><div class="math-vis-label">HỌC QUA HÌNH TRỰC QUAN · VISUAL LEARNING</div><h3>${Escape(vi)}</h3><p class="math-vis-en">${Escape(en)}</p><div class="math-vis-picture">${makeScene(kind)}</div><div class="math-vis-question"><b>Câu hỏi khai thác hình · Look and think</b><p>${Escape(question)}</p><details><summary>Xem gợi ý trả lời · Answer hint</summary><p>${Escape(answer)}</p></details></div><p class="math-vis-caution">Sơ đồ do dự án tự thiết kế theo chủ đề SGK Kết nối tri thức Toán 10; không phải hình chụp SGK. Giáo viên cần kiểm duyệt ví dụ và nhãn trước khi giảng dạy.</p></section>`}
window.MATH_VISUALS={render,count:ITEMS.length,kinds:ITEMS.map(x=>x[0])};
})();
