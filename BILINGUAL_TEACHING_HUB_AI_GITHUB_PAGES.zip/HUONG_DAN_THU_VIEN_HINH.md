# Bilingual Teaching Hub AI – Thư viện 110 hình trực quan lớp 10

- Đã tích hợp danh mục 110 hình từ Excel do giáo viên cung cấp: Toán 27, Vật lí 34, Hóa học 23, Sinh học 26.
- Mở mục **Thư viện 110 hình** trong thanh điều hướng. Lọc môn, tìm theo tên bài/hình, bấm hình để xem sơ đồ gốc, câu hỏi và gợi ý; chọn **Mở bài học** để tiếp tục học.
- Nguồn hiển thị là hình/sơ đồ của dự án, không phải bản quét ảnh SGK. Các tham chiếu trang là trang *bắt đầu bài* đối với môn có cột đó, không khẳng định là trang của hình.
- Bản ZIP được đóng gói giữ tên `BILINGUAL_TEACHING_HUB_AI_GITHUB_PAGES.zip` để tương thích với `deploy.yml` đã cấu hình. Khi tải lên GitHub, thay phiên bản ZIP cũ bằng bản mới và kiểm tra **Actions → build → deploy**.
- Giữ nguyên thư viện bài học, sơ đồ tương tác và bài tập song ngữ trước đây; ngân hàng bài tập SGK chưa hoàn thành hết 110 bài.
- Trước khi sử dụng trên lớp cần giáo viên bộ môn kiểm duyệt dữ liệu, tên hình, sơ đồ và gợi ý trả lời.
