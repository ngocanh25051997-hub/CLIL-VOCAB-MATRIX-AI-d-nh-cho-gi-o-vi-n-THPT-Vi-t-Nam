# Bilingual Teaching Hub AI — Học qua hình trực quan đủ 4 môn lớp 10

Phiên bản ngày 20/10/2026 (phát triển tiếp từ phiên bản Toán–Vật lí trực quan).

## Nội dung

- **Toán 10:** 27/27 bài có sơ đồ SVG riêng từ bản trước.
- **Vật lí 10:** 34/34 bài có sơ đồ SVG riêng từ bản trước.
- **Hóa học 10:** 23/23 bài có hình SVG gốc phù hợp chủ đề; có thanh thay đổi số hiệu nguyên tử, giai đoạn hình thành ion, ΔH, nhiệt độ ở bài thích hợp.
- **Sinh học 10:** 26/26 bài có hình SVG gốc phù hợp chủ đề; có thanh điều chỉnh mô hình môi trường ưu/nhược trương, hoạt tính enzyme, chu kì tế bào, tăng trưởng vi sinh vật, chu trình nhiễm virus ở bài thích hợp.
- Tổng **110/110 bài** có thành phần học qua hình trực quan, câu hỏi quan sát và gợi ý trả lời.
- Các phần học liệu cũ gồm thuật ngữ, công thức, bài tập song ngữ, câu hỏi tự kiểm tra, ghi chú giáo viên được giữ lại.

## Cách mở

1. Mở file `BILINGUAL_TEACHING_HUB_AI_HOA_SINH10_TRUC_QUAN.html` (không cần giải nén, xem offline).
2. Hoặc giải nén `BILINGUAL_TEACHING_HUB_AI_GITHUB_PAGES.zip` và mở `index.html` **cùng thư mục** `assets` và `data`.
3. Chọn môn → bài học → **Học qua hình & công thức**.
4. Thử các thanh điều chỉnh trên bài có tương tác. Dưới mỗi hình có câu hỏi quan sát, gợi ý và (với chủ đề phù hợp) liên kết tham khảo PhET.

## PhET: nguồn tham khảo, không phải mã/hình được sử dụng lại

PhET Interactive Simulations, University of Colorado Boulder: https://phet.colorado.edu

- Các liên kết trong website dẫn ra **mô phỏng gốc trên website PhET** để người dùng khám phá độc lập.
- SVG và cơ chế điều chỉnh trong Bilingual Teaching Hub AI là **mã và mô hình tự biên soạn**, không nhúng hoặc sao chép hình, video, tên/logo PhET làm thương hiệu.
- Tính năng tương tác lấy cảm hứng **triết lý học qua khám phá**, không tuyên bố đây là bản PhET, do PhET tài trợ/chứng nhận hoặc bản tương đương kỹ thuật.
- PhET công bố giấy phép CC BY-NC 4.0 cho các file mô phỏng HTML thông thường, áp dụng các điều kiện và yêu cầu ghi công riêng (https://phet.colorado.edu/en/licensing). Nếu tương lai dự định nhúng, dùng ảnh chụp, phát lại hoặc thương mại hóa, phải đánh giá giấy phép và xin phép thích hợp.

## Vấn đề cần kiểm duyệt

1. Danh mục tên bài căn cứ vào mục lục SGK Kết nối tri thức lớp 10 mà người dùng cung cấp; **chưa có chứng nhận kiểm duyệt nội dung tất cả các hình**.
2. Mô hình giản lược, không theo tỉ lệ; một số mô hình thể hiện quan hệ định tính hoặc giá trị giả định, không phải kết quả thí nghiệm đã đo.
3. Các câu hỏi/gợi ý do dự án biên soạn, **không phải câu nguyên văn hay đáp án chính thức của SGK**.
4. Học liệu biên soạn của các bài chưa có phiếu xác nhận của giáo viên bộ môn. Thực hiện rà soát kỹ từng chương trước khi sử dụng trong giờ học hoặc đưa vào hồ sơ khẳng định tính hiệu quả.
5. Không tự động gửi dữ liệu lên máy chủ/AI. Phần ghi chú lưu trên máy cục bộ của giáo viên, cần sao lưu khi dùng ở máy khác.

## Cập nhật GitHub Pages hiện có

Với repository đã cấu hình `deploy.yml` để mở gói `BILINGUAL_TEACHING_HUB_AI_GITHUB_PAGES.zip` rồi xuất bản thư mục `dist`:

1. Tải `BILINGUAL_TEACHING_HUB_AI_GITHUB_PAGES.zip` bản mới, xác nhận tên *không có* `(1)` hay `(2)`.
2. Trên trang GitHub, sao lưu gói cũ, sau đó cập nhật **chính xác tên file** ZIP tại thư mục gốc repository. Nếu trình tải file GitHub từ chối ghi đè, có thể xóa file cũ trước rồi upload bản mới (lưu ý thao tác xóa có thể tự kích hoạt một workflow không thành công tạm thời); hoặc đặt tên khác và đổi đúng 1 tên file trong `deploy.yml`.
3. Commit trên `main`, kiểm tra Actions → `build` và `deploy` dấu xanh.
4. Mở URL GitHub Pages bằng chế độ tải lại không dùng cache, kiểm tra bốn môn và các thanh tương tác.
5. Không upload chỉ file HTML độc lập vào repository nếu mục tiêu deploy đang dùng ZIP đã cấu hình.

## Kiểm thử kỹ thuật đã thực hiện

- 110/110 bài có tab trực quan; bao gồm 23 Hóa, 26 Sinh, 27 Toán và 34 Vật lí.
- 49/49 bài Hóa–Sinh có SVG gốc kết xuất thành công bằng trình duyệt Chromium thử nghiệm.
- Với các trường hợp có thanh điều chỉnh được thử, nội dung SVG đổi khi kéo thanh.
- Không ghi nhận lỗi JS trong lượt tự động mở 110 bài.
- Thử layout di động 390px không tràn ngang.

**Trạng thái:** Bản thử nghiệm giáo dục – cần giáo viên bộ môn kiểm duyệt, chưa thay thế sách giáo khoa và không phải bản triển khai đã xác minh trên GitHub công khai.
