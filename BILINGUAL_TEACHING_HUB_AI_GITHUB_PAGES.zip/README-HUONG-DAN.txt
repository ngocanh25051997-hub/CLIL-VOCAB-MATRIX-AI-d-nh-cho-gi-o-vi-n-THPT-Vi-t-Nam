# Bilingual Teaching Hub AI — Word Bank & Exercises Edition

Phiên bản cập nhật 21/10/2026. Giữ nguyên 110 sơ đồ trực quan và giao diện của phiên bản Thư viện 110 hình.

## Dữ liệu
- 110 bài lớp 10: Toán 27, Vật lí 34, Hóa học 23, Sinh học 26.
- 1217 mục thuật ngữ Anh–Việt (gồm mục cũ và bổ sung; có thể lặp giữa nhiều bài, không phải số từ duy nhất).
- 330 cụm từ theo chủ đề (3 cụm/bài).
- 660 bài luyện mới (6 dạng/bài: nối cột, điền khuyết, dịch ý, đọc hình, sửa lỗi, đọc hiểu khoa học).
- 212 bài luyện cũ vẫn giữ và 53 câu/nhóm câu tham chiếu SGK đã nhập từ phiên bản trước.

## Cách xem
Mở index.html (trong bộ ZIP) hoặc file HTML độc lập. Chọn môn → bài → tab **Từ vựng & cụm từ**, **Bài tập song ngữ**. Trong bài tập dùng bộ lọc 'Chọn dạng bài'. Các gợi ý đáp án được ẩn mặc định.

## Trạng thái chuyên môn
Thuật ngữ và bài luyện bổ sung do dự án biên soạn dựa trên chủ đề SGK Kết nối tri thức và khung chương trình lớp 10, không phải nội dung được trích nguyên văn SGK. Chưa có xác nhận kiểm duyệt đầy đủ của giáo viên Toán/Lý/Hóa/Sinh; cần kiểm tra ngữ nghĩa, độ khó và đáp án trước khi giao học sinh. Bài tập SGK vẫn chỉ gồm các mục đã nhập trong phiên bản trước, không được quảng bá là toàn bộ bài tập SGK.

## Cập nhật GitHub Pages
Repository cũ sử dụng GitHub Actions với dòng `unzip -o BILINGUAL_TEACHING_HUB_AI_GITHUB_PAGES.zip -d dist`. Không sửa workflow. Sao lưu, thay thế file ZIP cùng tên trong gốc repository, Commit changes, vào Actions kiểm tra build/deploy thành công.

## Lưu ý
Mô phỏng/hình SVG không đổi. Không đặt Gemini API key vào website tĩnh.
