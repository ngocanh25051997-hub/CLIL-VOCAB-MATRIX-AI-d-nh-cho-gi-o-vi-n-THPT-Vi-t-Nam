# Bilingual Teaching Hub AI | NỀN TẢNG HỖ TRỢ GIẢNG DẠY SONG NGỮ · LỚP 10

## Phiên bản thiết kế lại (20/10/2026)

Website học liệu song ngữ Anh–Việt theo SGK **Kết nối tri thức với cuộc sống**, tập trung 4 môn lớp 10: Toán, Vật lí, Hóa học, Sinh học.

**Đây là nguyên mẫu giáo dục, không phải hệ thống học liệu đã qua phê duyệt.** Website chạy tĩnh, không nhúng API key, không gọi AI trực tiếp và không thu thập thông tin học sinh lên máy chủ.

### Phạm vi dữ liệu

| Môn | Bài/mục có trong danh mục | Bài học mẫu chi tiết |
|---|---:|---|
| Toán 10 | 27 | Bài 16 — Hàm số bậc hai |
| Vật lí 10 | 34 | Bài 15 — Định luật II Newton |
| Hóa học 10 | 23 | Bài 11 — Liên kết ion |
| Sinh học 10 | 26 | Bài 8 — Tế bào nhân thực |
| **Tổng** | **110** | **4** |

**Bài mẫu có:** tóm tắt kiến thức & mục tiêu, 11 thuật ngữ/bài, công thức/cách đọc hoặc sơ đồ khoa học, mô hình tương tác riêng, ví dụ giải từng bước, 3 bài tập SGK tham chiếu trang/bài được biên tập tiếng Anh, hoạt động 4Cs & ma trận ngôn ngữ CLIL, 3 câu trắc nghiệm/bài, ghi chú và xuất CSV/JSON.

**Chỉ có tên/chuỗi từ khóa** cho 106 mục còn lại. Không đánh đồng những mục này với bài mẫu hoàn chỉnh hoặc nội dung đã kiểm duyệt.

### Cấu trúc tệp

- `index.html` — trang web xuất bản lên GitHub Pages.
- `assets/styles.css` — thiết kế giao diện PC/di động/in ấn.
- `assets/app.js` — điều hướng, mô phỏng, luyện tập, xuất tệp.
- `data/corpus.js` — dữ liệu web để chạy trực tiếp trên trình duyệt (không cần máy chủ).
- `data/catalogue-grade10.json` — danh mục 110 bài/mục.
- `data/lesson-packs.json` — nội dung 4 bài mẫu và câu hỏi tham chiếu SGK.
- `DANH_MUC_LOP_10.csv` — bảng danh mục có thể mở bằng Excel.
- `DOI_CHIEU_BAI_TAP_SGK.csv` — danh sách mã câu hỏi và trang để kiểm tra nguồn.
- `preview-*.png` — ảnh chụp thực tế từ trình duyệt kiểm thử.

### Sử dụng trên máy

**Cách dễ nhất:** mở file `BILINGUAL_TEACHING_HUB_AI_LOP10.html` độc lập trong Chrome/Edge. Nếu dùng bản mã nguồn nhiều tệp, giữ nguyên cấu trúc thư mục và mở `index.html`.

1. Chọn một môn (Toán, Vật lí, Hóa học, Sinh học).
2. Gõ tên bài hoặc chọn chương trong danh mục trái.
3. Nhấn bài có dấu ✦ để mở **bài mẫu chi tiết**.
4. Dùng các tab: Tổng quan → Từ vựng → Công thức & trực quan → Bài tập SGK → Hoạt động CLIL → Tự kiểm tra → Ghi chú & xuất.
5. Thay đổi hệ số đồ thị / lực & khối lượng, chuyển trạng thái mô hình ion hoặc chọn bào quan tế bào.
6. Xuất bảng từ vựng, bài tập (CSV) hoặc ghi chú học liệu (JSON). Nút In dùng hộp thoại in của trình duyệt (có thể chọn **Save as PDF**).

Ghi chú kiểm duyệt được lưu **cục bộ trong trình duyệt** qua localStorage. Xóa dữ liệu trình duyệt có thể làm mất ghi chú, nên xuất JSON làm bản sao.

### Đưa lên GitHub Pages (không cần lập trình)

1. Mở repository GitHub thầy/cô đang dùng. Sao lưu phiên bản website cũ nếu cần.
2. **Giải nén tệp ZIP**. Tải lên toàn bộ `index.html`, thư mục `assets/` và `data/` vào **thư mục gốc** của repository (giữ đúng tên và cấu trúc).
3. Chọn **Commit changes**.
4. Vào **Settings → Pages**, chọn **Deploy from a branch**, Branch `main`, Folder `/(root)`, rồi **Save** (nếu repository đang dùng GitHub Actions, cần kiểm tra workflow trước khi đổi cấu hình).
5. Sau khi GitHub Pages hoàn tất deployment, mở URL được GitHub cung cấp và thử: chọn môn, xem từ vựng, đồ thị và xuất CSV.

Không được chỉ tải **file ZIP nguyên vẹn** lên repository để mong GitHub Pages tự giải nén. Không đưa Gemini API key vào JavaScript, HTML, hoặc GitHub public repository.

### Phạm vi bản quyền và kiểm duyệt

- Trang web dùng SGK/CTGDPT 2018 làm tài liệu tham chiếu; không nhúng ảnh trang SGK.
- Bài tập được **rút gọn/diễn đạt lại** và dẫn mã số/trang tương ứng. Lời giải, bản tiếng Anh, sơ đồ/mô phỏng và hoạt động CLIL do dự án biên soạn.
- Mục tiêu chương trình trên web là **diễn giải mục tiêu cần đạt**, không phải trích nguyên văn toàn bộ văn bản chương trình.
- Giáo viên chuyên môn cần kiểm tra dữ kiện, thuật ngữ, tính đúng đắn và mức độ phù hợp trước khi sử dụng chính thức.
- Không tuyên bố nội dung đã được Bộ GDĐT/NXB kiểm duyệt, không ghi số liệu thử nghiệm giả.
- Nếu công khai thêm các bài tập trích dẫn dài, hình ảnh hoặc nội dung nguyên văn trong SGK, cần đảm bảo quyền sử dụng và sự cho phép tương ứng.

### Những việc chưa làm

- Chưa biên soạn sâu toàn bộ 110 bài/mục.
- Chưa tích hợp chức năng tạo bài mới bằng Gemini API.
- Chưa có hệ thống tài khoản, LMS hoặc lưu kết quả học sinh trên máy chủ.
- Chưa có phê duyệt nội dung khoa học từ tổ bộ môn hoặc minh chứng hiệu quả triển khai thực tế.

### Kiểm tra kỹ thuật đã thực hiện

- Duyệt qua 4 môn, mở các tab và 4 bộ mô hình: **đạt**.
- Lọc danh mục, tìm bài trên di động: **đạt**.
- Tải CSV từ vựng / bài tập và JSON học liệu: **đạt**.
- Chấm 3 câu trắc nghiệm và phản hồi: **đạt**.
- Lưu ghi chú trong trình duyệt: **đạt**.
- Không ghi nhận JavaScript page errors trong lần kiểm thử bằng Chromium; tình trạng sử dụng thực tế còn phụ thuộc thiết bị và trình duyệt của giáo viên.

> Dự án phục vụ nghiên cứu và thực nghiệm EMI/CLIL ở THPT. Một bài mẫu tốt có kiểm chứng quan trọng hơn việc tự động tạo hàng trăm bài mà chưa rà soát.
